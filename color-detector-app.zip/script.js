
let canvas = document.getElementById('imageCanvas');
let ctx = canvas.getContext('2d');
let colorOutput = document.getElementById('colorOutput');
let colorBox = document.getElementById('colorBox');
let colors = [];

document.getElementById('imageUpload').addEventListener('change', function (e) {
  let reader = new FileReader();
  reader.onload = function (event) {
    let img = new Image();
    img.onload = function () {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
    };
    img.src = event.target.result;
  };
  reader.readAsDataURL(e.target.files[0]);
});

canvas.addEventListener('click', function (e) {
  let rect = canvas.getBoundingClientRect();
  let x = e.clientX - rect.left;
  let y = e.clientY - rect.top;
  let data = ctx.getImageData(x, y, 1, 1).data;
  let r = data[0], g = data[1], b = data[2];
  let colorName = getClosestColor(r, g, b);
  colorOutput.textContent = `Color: ${colorName} | RGB(${r}, ${g}, ${b})`;
  colorBox.style.backgroundColor = `rgb(${r},${g},${b})`;
});

function getClosestColor(r, g, b) {
  let minDistance = Infinity;
  let closest = "Unknown";
  colors.forEach(color => {
    let dist = Math.sqrt(
      Math.pow(r - color.R, 2) +
      Math.pow(g - color.G, 2) +
      Math.pow(b - color.B, 2)
    );
    if (dist < minDistance) {
      minDistance = dist;
      closest = color.Name;
    }
  });
  return closest;
}

fetch('colors.csv')
  .then(response => response.text())
  .then(data => {
    let lines = data.split('\n');
    lines.forEach(line => {
      let [Name, R, G, B] = line.split(',');
      if (Name && R && G && B && Name !== "Name") {
        colors.push({ Name, R: parseInt(R), G: parseInt(G), B: parseInt(B) });
      }
    });
  });
